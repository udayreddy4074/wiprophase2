import './App.css';
import Product from './Product';
import Product1 from './Product1';
import Product2 from './Product2';

function App() {
  return (
    <div className="App">
     <Product2/>
    </div>
  );
}

export default App;

