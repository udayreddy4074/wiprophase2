﻿using System;
using System.Data.SqlClient;

class Program
{
    static string connectionString = "Server=LAPTOP-0VO0SEO9\\SQLEXPRESS02;Database=DemoDb1;Integrated Security=True;";

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nChoose an operation:");
            Console.WriteLine("1. Insert Employee");
            Console.WriteLine("2. View Employees");
            Console.WriteLine("3. Update Employee");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");
            Console.Write("Enter choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    InsertEmployee();
                    break;
                case "2":
                    ViewEmployees();
                    break;
                case "3":
                    UpdateEmployee();
                    break;
                case "4":
                    DeleteEmployee();
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Invalid choice. Try again.");
                    break;
            }
        }
    }

    // ✅ Create (Insert Employee)
    static void InsertEmployee()
    {
        Console.Write("Enter Employee ID: ");
        int id = int.Parse(Console.ReadLine());
        Console.Write("Enter Name: ");
        string name = Console.ReadLine();
        Console.Write("Enter Department: ");
        string dept = Console.ReadLine();
        Console.Write("Enter Salary: ");
        float salary = float.Parse(Console.ReadLine());

        string query = "INSERT INTO Employee (id, name, dept, salary) VALUES (@id, @name, @dept, @salary)";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@dept", dept);
                cmd.Parameters.AddWithValue("@salary", salary);

                int rows = cmd.ExecuteNonQuery();
                Console.WriteLine(rows > 0 ? "Employee inserted successfully." : "Failed to insert employee.");
            }
        }
    }

    // ✅ Read (View Employees)
    static void ViewEmployees()
    {
        string query = "SELECT * FROM Employee";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("\nID | Name | Department | Salary");
                    Console.WriteLine("--------------------------------");
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["id"]} | {reader["name"]} | {reader["dept"]} | {reader["salary"]}");
                    }
                }
            }
        }
    }

    // ✅ Update (Modify Employee Details)
    static void UpdateEmployee()
    {
        Console.Write("Enter Employee ID to Update: ");
        int id = int.Parse(Console.ReadLine());
        Console.Write("Enter New Name: ");
        string name = Console.ReadLine();
        Console.Write("Enter New Department: ");
        string dept = Console.ReadLine();
        Console.Write("Enter New Salary: ");
        float salary = float.Parse(Console.ReadLine());

        string query = "UPDATE Employee SET name=@name, dept=@dept, salary=@salary WHERE id=@id";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@dept", dept);
                cmd.Parameters.AddWithValue("@salary", salary);

                int rows = cmd.ExecuteNonQuery();
                Console.WriteLine(rows > 0 ? "Employee updated successfully." : "Employee not found.");
            }
        }
    }

    // ✅ Delete (Remove Employee)
    static void DeleteEmployee()
    {
        Console.Write("Enter Employee ID to Delete: ");
        int id = int.Parse(Console.ReadLine());

        string query = "DELETE FROM Employee WHERE id=@id";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", id);

                int rows = cmd.ExecuteNonQuery();
                Console.WriteLine(rows > 0 ? "Employee deleted successfully." : "Employee not found.");
            }
        }
    }
}
