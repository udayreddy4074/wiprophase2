﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string Branch { get; set; }

        [Required]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Registration number must be 10 digits")]
        public string RegNo { get; set; }
    }
}
