// src/components/AddTask.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddTask = () => {
  const [task, setTask] = useState({
    name: '',
    description: '',
    date: '',
    createdBy: ''
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTask({
      ...task,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newTask = { ...task, id: new Date().getTime().toString() };
    // Call action to add task here
    // After adding, navigate to home page
    navigate('/');
  };

  return (
    <div>
      <h2>Add New Task</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          value={task.name}
          onChange={handleChange}
          placeholder="Task Name"
        />
        <input
          type="text"
          name="description"
          value={task.description}
          onChange={handleChange}
          placeholder="Task Description"
        />
        <input
          type="date"
          name="date"
          value={task.date}
          onChange={handleChange}
        />
        <input
          type="text"
          name="createdBy"
          value={task.createdBy}
          onChange={handleChange}
          placeholder="Created By"
        />
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
};

export default AddTask;
