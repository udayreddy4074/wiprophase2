// src/components/Home.js
import React, { useReducer } from 'react';
import { Link } from 'react-router-dom';
import { taskReducer } from '../reducers/taskReducer';

const Home = () => {
  const [tasks, dispatch] = useReducer(taskReducer, []);

  return (
    <div>
      <h2>Task List</h2>
      <Link to="/add">Add New Task</Link>
      <ul>
        {tasks.map((task) => (
          <li key={task.id}>
            <span>{task.name}</span> - 
            <span>{task.description}</span> - 
            <span>{task.date}</span> - 
            <span>{task.createdBy}</span>
            <Link to={`/edit/${task.id}`}>Edit</Link>
            <Link to={`/delete/${task.id}`}>Delete</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;
