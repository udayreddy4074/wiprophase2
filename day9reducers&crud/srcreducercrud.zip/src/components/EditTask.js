// src/components/EditTask.js
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditTask = () => {
  const [task, setTask] = useState({
    name: '',
    description: '',
    date: '',
    createdBy: ''
  });

  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch the task details using the id from the route params
    // For now, we'll mock the task data
    setTask({
      name: 'Sample Task',
      description: 'This is a task description.',
      date: '2025-03-12',
      createdBy: 'Admin'
    });
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTask({
      ...task,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle task update
    // After update, navigate to home page
    navigate('/');
  };

  return (
    <div>
      <h2>Edit Task</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          value={task.name}
          onChange={handleChange}
          placeholder="Task Name"
        />
        <input
          type="text"
          name="description"
          value={task.description}
          onChange={handleChange}
          placeholder="Task Description"
        />
        <input
          type="date"
          name="date"
          value={task.date}
          onChange={handleChange}
        />
        <input
          type="text"
          name="createdBy"
          value={task.createdBy}
          onChange={handleChange}
          placeholder="Created By"
        />
        <button type="submit">Update Task</button>
      </form>
    </div>
  );
};

export default EditTask;
