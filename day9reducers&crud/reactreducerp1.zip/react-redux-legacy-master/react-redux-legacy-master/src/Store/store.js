import { applyMiddleware, legacy_createStore } from "redux";
import { thunk } from "redux-thunk";
import reducers from "../Reducers/CombineReducers";

const store = legacy_createStore(
    reducers, {}, applyMiddleware(thunk));

    console.log("State is " + store.getState());


    export default store;
    